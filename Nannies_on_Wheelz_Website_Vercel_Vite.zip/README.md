# Nannies on Wheelz Website (Vite + React + Tailwind)

## Deploy on Vercel
- Framework Preset: **Vite**
- Root Directory: `./`
- Build Command: `npm run build`
- Output Directory: `dist`
- Install Command: `npm install`

## Forms
Replace these placeholders in `src/App.jsx`:
- YOUR_BOOKING_FORM_ID
- YOUR_HIRING_FORM_ID

## Logo
Logo is at `public/logo.png` and referenced as `/logo.png`.
